'use strict';
process.env.SHALEAN_RELEASE_SHA = process.env.SHALEAN_RELEASE_SHA || require('./build-meta.json').artifact_sha;
require('./server.next.js');
