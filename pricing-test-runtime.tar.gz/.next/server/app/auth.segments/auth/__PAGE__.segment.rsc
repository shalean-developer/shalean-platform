2:"$Sreact.fragment"
3:"static/chunks/98500-202fb27570ee6051.js"
4:"static/chunks/38437-fc6338724e0a505b.js"
5:"static/chunks/app/auth/page-71f53064e3f437e4.js"
6:I[98500,["98500","$3","38437","$4","8365","$5"],""]
7:I[38437,["98500","$3","38437","$4","8365","$5"],"Image"]
8:I[57121,[],""]
9:I[74581,[],""]
d:"$Sreact.suspense"
e:"AuthRoleChoicePageClient"
f:I[34552,["98500","$3","38437","$4","8365","$5"],"$e"]
10:I[90484,[],"OutletBoundary"]
13:"ViewportBoundary"
14:I[90484,[],"$13"]
15:"MetadataBoundary"
16:I[90484,[],"$15"]
17:I[86869,[],"IconMark"]
b:X
c:[["children",{"s":"__PAGE__","h":160,"d":{"r":["$","$2","c",{"children":[["$","$d",null,{"fallback":["$","div",null,{"className":"bg-transparent","children":["$","p",null,{"className":"text-center text-sm text-zinc-600 dark:text-zinc-400","children":"Loading…"}]}],"children":[["$","$Lf",null,{}],["$","p",null,{"className":"mt-8 text-center text-xs leading-relaxed text-zinc-500 dark:text-zinc-400","children":["By continuing, you agree to our"," ",["$","$L6",null,{"href":"/terms-of-service","className":"font-medium text-zinc-600 underline underline-offset-2 hover:text-zinc-900 dark:text-zinc-300","children":"Terms of Service"}]," ","and"," ",["$","$L6",null,{"href":"/privacy-policy","className":"font-medium text-zinc-600 underline underline-offset-2 hover:text-zinc-900 dark:text-zinc-300","children":"Privacy Policy"}],"."]}]]}],null,["$","$L10",null,{"children":["$","$d",null,{"name":"Next.MetadataOutlet","children":"$@11"}]}]]}],"p":"$@12","v":null,"s":"$b"}}]]
1:[["children",{"s":"auth","h":64,"d":{"r":["$","$2","c",{"children":[null,["$","div",null,{"className":"flex min-h-dvh flex-col items-center bg-white px-5 py-8 sm:py-10 dark:bg-zinc-950","children":[["$","div",null,{"className":"mb-16 flex w-full max-w-[600px] flex-col items-center text-center sm:mb-24","children":["$","$L6",null,{"href":"/","className":"inline-flex flex-col items-center gap-2 transition hover:opacity-90","suppressHydrationWarning":true,"children":[[["$","$L7","20260715c",{"src":"/images/shalean-logo.png?v=20260715c","alt":"Shalean Cleaning Services","width":278,"height":80,"className":"object-contain object-left min-w-0 max-w-full h-9 w-auto sm:h-10","sizes":"(max-width: 640px) 140px, 200px","priority":true}]],["$","p",null,{"className":"text-sm text-zinc-500 dark:text-zinc-400","suppressHydrationWarning":true,"children":"Professional cleaning, simplified."}]]}]}],["$","div",null,{"className":"w-full max-w-[600px]","children":["$","$L8",null,{"parallelRouterKey":"children","template":["$","$L9",null,{}]}]}]]}]]}],"p":"$@a","v":null,"s":"$b"},"c":"$Qc"}]]
0:{"t":{"t":{"s":"","h":16,"c":"$Q1"},"h":{"r":["$","$2","h",{"children":[null,["$","$L14",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1, viewport-fit=cover"}],["$","meta","2",{"name":"theme-color","content":"#5A73D8"}]]}],["$","$L16",null,{"children":[["$","div",null,{"hidden":true,"children":["$","$d",null,{"name":"Next.Metadata","children":[["$","title","0",{"children":"Sign in — Shalean | STAGING"}],["$","meta","1",{"name":"description","content":"Continue as a customer or cleaner."}],["$","link","2",{"rel":"manifest","href":"/site.webmanifest"}],["$","meta","3",{"name":"robots","content":"noindex, nofollow"}],["$","link","4",{"rel":"canonical","href":"https://pricing-test.shalean.co.za"}],["$","meta","5",{"property":"og:title","content":"Cleaning Services Cape Town from R250 | Shalean"}],["$","meta","6",{"property":"og:description","content":"Book vetted cleaning services in Cape Town from R250. Compare home, deep, move, Airbnb, office and carpet cleaning and see your price before checkout."}],["$","meta","7",{"property":"og:url","content":"https://pricing-test.shalean.co.za"}],["$","meta","8",{"property":"og:site_name","content":"Shalean Cleaning Services"}],["$","meta","9",{"property":"og:locale","content":"en_ZA"}],["$","meta","10",{"property":"og:image","content":"https://pricing-test.shalean.co.za/images/marketing/homepage-hero-cleaning-team-cape-town-og.webp"}],["$","meta","11",{"property":"og:image:width","content":"1200"}],["$","meta","12",{"property":"og:image:height","content":"630"}],["$","meta","13",{"property":"og:image:alt","content":"Professional cleaning services in Cape Town"}],["$","meta","14",{"property":"og:type","content":"website"}],["$","meta","15",{"name":"twitter:card","content":"summary_large_image"}],["$","meta","16",{"name":"twitter:title","content":"Cleaning Services Cape Town from R250 | Shalean"}],["$","meta","17",{"name":"twitter:description","content":"Book vetted cleaning services in Cape Town from R250. Compare home, deep, move, Airbnb, office and carpet cleaning and see your price before checkout."}],["$","meta","18",{"name":"twitter:image","content":"https://pricing-test.shalean.co.za/images/marketing/homepage-hero-cleaning-team-cape-town-og.webp"}],["$","link","19",{"rel":"icon","href":"/favicon.ico?d70d9b77fc73c691","type":"image/x-icon","sizes":"16x16"}],["$","link","20",{"rel":"icon","href":"/icon.png?da87862366d69d52","type":"image/png","sizes":"512x512"}],["$","link","21",{"rel":"apple-touch-icon","href":"/apple-icon.png?7a83217b0fd01ef3","type":"image/png","sizes":"180x180"}],["$","$L17","22",{}]]}]}],null]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}],"p":"$@18","v":null,"s":"$b"}},"a":"$@19","u":"$@1a","b":"6GOa9USuMu3P0k1pM1yO5"}
11:null
1a:true
b:300
b:C
19:0
a:"$undefined"
18:"$undefined"
12:"$undefined"
