:HL["/_next/static/media/0b78ff376f6b9734-s.p.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/723e11e5093b8e80.p.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/css/0c51755a10f2b223.css","style"]
:HL["/_next/static/css/adcf1ab37a27fc67.css","style"]
:HL["/_next/static/css/55629339f2382de0.css","style"]
2:[["children",{"s":"__PAGE__","h":160}]]
1:[["children",{"s":"terms-of-service","h":64,"c":"$Q2"}]]
0:{"b":"6GOa9USuMu3P0k1pM1yO5","t":{"t":{"s":"","h":16,"c":"$Q1"}}}
